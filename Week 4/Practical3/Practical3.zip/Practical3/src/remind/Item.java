package remind;

public abstract class Item {
    public abstract void print();
}
