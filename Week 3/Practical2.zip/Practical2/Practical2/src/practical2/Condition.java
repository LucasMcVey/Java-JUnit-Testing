package practical2;

/**
 * @author moon0016
 */
public interface Condition {
    boolean satisfies(Boat b);
}
